Daniel Louis
Operation Sysytems Fall 2019 (8:45 section)

Lab02

For this lab I implemented a way to read input from the keyboard into the kernel through the interrupt 33. The first input will get a string that is at most 80 
characters long and store it into a char array. The second input will capture an integer from the keyboard and store it in an int. Also wrote a function that can 
print an integer to the screen or to print. 

To test this there is a madlib to fill out that will take the input from the keyboard and fill it in. The madlib will be printed out to printer.out.
