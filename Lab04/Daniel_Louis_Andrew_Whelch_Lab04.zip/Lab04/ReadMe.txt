Daniel Louis, Andrew Whelch 
Operation Sysytems Fall 2019 (8:45 section)

Lab04

For this lab we added funciontality to the kernel with a simple terminate program added to the interrupt handler 21. Also we tested 
functionality to allow programs access to our kernel commands through the interrupt calls and traps. So, that other programs besides our kernel can 
access our kernel commands. We also pushed files from the disk into memory and run the program from memory. 

To test this run the kernel with our shell script and it will open and run the fib.c program. 



